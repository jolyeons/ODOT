﻿using EComm.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EComm.DataAccess
{
    internal class EFRepository : DbContext, IRepository
    {
        private string connStr;

        public DbSet<Product> Products { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public EFRepository(string connStr)
        {
            this.connStr = connStr;
        }
        public IEnumerable<Product> GetAllProducts()
        {
            return Products;
        }
        public IEnumerable<Customer> GetAllCustomers()
        {
            return Customers;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlServer(this.connStr);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>().ToTable("Product");
            modelBuilder.Entity<Customer>().ToTable("Customer");
        }

    }

    public static class EFRepositoryFactory
    {
        public static IRepository GetInstance(string connStr)
        {
            return new EFRepository(connStr);
        }
    }
}
