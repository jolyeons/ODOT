﻿using EComm.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EComm.Web.ViewModels
{
    public class MyViewModel
    {
        public IEnumerable<Customer> Customers { get; set; }
        public int selected { get; set; }

    }
}
