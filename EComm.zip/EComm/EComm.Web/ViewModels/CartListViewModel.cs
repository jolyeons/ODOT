﻿using EComm.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EComm.Web.ViewModels
{
    public class CartListViewModel
    {
        ShoppingCart ShoppingCart { get; set; }
    }
}
