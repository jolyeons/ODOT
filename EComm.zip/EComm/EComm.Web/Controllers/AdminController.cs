﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using EComm.Web.ViewModels;
using System.Security.Claims;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace EComm.Web.Controllers
{
    [Authorize(Policy = "AdminOnly")]
    public class AdminController : Controller
    {
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        [AllowAnonymous]
        public IActionResult Login(bool Logout = false)
        {
            if (Logout)
            {
                ViewBag.Message = "You have been logged out";
            }
            if(HttpContext.User.HasClaim("IsAdmin", "true"))
            {
                ViewBag.Message = "You are logged in already as " + HttpContext.User.Identity.Name;
            }
            if (User.Identity.IsAuthenticated)
            {
                ViewBag.Message += " and you are Authenticated";
            }
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel lvm)
        {
            if (!ModelState.IsValid)
            {
                return View(lvm);
            }
            bool auth = (lvm.Username == "test" && lvm.Password == "password");
            if (!auth)
            {
                return View(lvm);
            }
            var principal = new ClaimsPrincipal(new ClaimsIdentity(new List<Claim> { new Claim(ClaimTypes.Name, lvm.Username), new Claim("IsAdmin", "true") }, "ManualAuthentication"));
            await HttpContext.Authentication.SignInAsync("Cookie", principal);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.Authentication.SignOutAsync("Cookie");
            return RedirectToAction("Login", "Admin", new { Logout = true });
        }
    }
}
