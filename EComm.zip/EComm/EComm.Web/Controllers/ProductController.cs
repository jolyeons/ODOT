﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EComm.DataAccess;
using EComm.Web.Models;
using System.Text;
using EComm.Web.ViewModels;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace EComm.Web
{
    public class ProductController : Controller
    {
        private IRepository repository;

        public ProductController(IRepository repository)
        {
            this.repository = repository;
        }

        [Route("product/{id:int}")]
        public IActionResult Detail(int id)
        {
            var model = repository.GetAllProducts().SingleOrDefault(p => p.Id == id);

            if(model == null)
            {
                return NotFound();
            }
            return View(model);
        }

        [HttpPost]
        public IActionResult AddToCart(int id, int quantity)
        {
            var product = repository.GetAllProducts().SingleOrDefault(p => p.Id == id);
            byte[] data;
            ShoppingCart cart;
            bool b = HttpContext.Session.TryGetValue("ShoppingCart", out data);
            if (b)
            {
                cart = ShoppingCart.FromJson(Encoding.UTF8.GetString(data));
            }
            else
            {
                cart = new ShoppingCart();
            }

            var lineItem = cart.LineItems.SingleOrDefault(item => item.Product.Id == id);

            if (lineItem != null)
            {
                lineItem.Quantity += quantity;
            }
            else
            {
                lineItem = new ShoppingCart.LineItem
                {
                    Product = product,
                    Quantity = quantity
                };
                cart.LineItems.Add(lineItem);
            }
            data = Encoding.UTF8.GetBytes(cart.AsJson());
            HttpContext.Session.Set("ShoppingCart", data);


            string message = $"You added {product.ProductName} (x{quantity}) to your cart at a total cost of {lineItem.TotalCost:C}.";
            ViewBag.Message = message;
            return PartialView();
        }

        [HttpPost]
        public IActionResult RemoveFromCart(int id)
        {
            var product = repository.GetAllProducts().SingleOrDefault(p => p.Id == id);
            byte[] data;
            ShoppingCart cart;
            bool b = HttpContext.Session.TryGetValue("ShoppingCart", out data);
            if (b)
            {
                cart = ShoppingCart.FromJson(Encoding.UTF8.GetString(data));
            }
            else
            {
                cart = new ShoppingCart();
            }

            var lineItem = cart.LineItems.SingleOrDefault(item => item.Product.Id == id);
            cart.LineItems.Remove(lineItem);
            
            data = Encoding.UTF8.GetBytes(cart.AsJson());
            HttpContext.Session.Set("ShoppingCart", data);


            string message = $"You removed {product.ProductName} from your cart.";
            ViewBag.Message = message;
            return PartialView();
        }

        public IActionResult Cart()
        {
            byte[] data;
            ShoppingCart cart;
            bool b = HttpContext.Session.TryGetValue("ShoppingCart", out data);
            if (b)
            {
                cart = ShoppingCart.FromJson(Encoding.UTF8.GetString(data));
            }
            else
            {
                cart = new ShoppingCart();
            }

            var model = new ShoppingCartViewModel();
            model.Cart = cart;
            return View(model);
        }

        public IActionResult GetCart()
        {
            byte[] data;
            ShoppingCart cart;
            bool b = HttpContext.Session.TryGetValue("ShoppingCart", out data);
            if (b)
            {
                cart = ShoppingCart.FromJson(Encoding.UTF8.GetString(data));
            }
            else
            {
                cart = new ShoppingCart();
            }
            return PartialView("_CartList",cart);
        }

        [HttpPost]
        public IActionResult Checkout(ShoppingCartViewModel scvm)
        {
            if (!ModelState.IsValid)
            {
                //todo
                return View(scvm);
            }
            //todo
            HttpContext.Session.Clear();
            return View("ThankYou");
        }

        [HttpPost]
        public IActionResult Edit(int id, int idk)
        {
            string str = "the id is: " + id + ", and also idk" + idk;
            return Content(str, "text/html");
        }
    }
}
